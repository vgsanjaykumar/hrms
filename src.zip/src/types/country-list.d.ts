declare module 'country-list' {
  export function getNames(): string[];
}
